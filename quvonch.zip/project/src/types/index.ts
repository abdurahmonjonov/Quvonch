export interface Product {
  id: string;
  name: string;
  nameUz: string;
  price: number;
  originalPrice?: number;
  image: string;
  images: string[];
  category: string;
  rating: number;
  reviews: number;
  description: string;
  descriptionUz: string;
  inStock: boolean;
  featured?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  nameUz: string;
  icon: string;
  color: string;
  productCount: number;
}

export interface Testimonial {
  id: string;
  name: string;
  nameUz: string;
  text: string;
  textUz: string;
  rating: number;
  avatar: string;
  location: string;
}