import React from 'react';
import { 
  ChevronRight, 
  Star, 
  Award, 
  Truck, 
  Shield, 
  HeadphonesIcon,
  Smartphone,
  Shirt,
  Home,
  Dumbbell,
  Book,
  Sparkles,
  Package
} from 'lucide-react';
import { categories, products, testimonials } from '../data/mockData';
import { Product } from '../types';
import ProductCard from './ProductCard';

interface HomepageProps {
  onPageChange: (page: string) => void;
  onProductClick: (product: Product) => void;
}

const Homepage: React.FC<HomepageProps> = ({ onPageChange, onProductClick }) => {
  const featuredProducts = products.filter(p => p.featured);

  const getIconComponent = (iconName: string) => {
    const icons: { [key: string]: React.ComponentType<{ className?: string }> } = {
      'Smartphone': Smartphone,
      'Shirt': Shirt,
      'Home': Home,
      'Dumbbell': Dumbbell,
      'Book': Book,
      'Sparkles': Sparkles,
    };
    
    const IconComponent = icons[iconName] || Package;
    return <IconComponent className="h-8 w-8 text-white" />;
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors duration-300">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-700 via-green-600 to-green-500 overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Quvonch bilan <span className="text-yellow-300">Xarid Qiling!</span>
            </h1>
            <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
              Eng sifatli mahsulotlar, eng yaxshi narxlar va tez yetkazib berish bilan sizning xaridingizni quvonchga aylantirymiz!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onPageChange('products')}
                className="px-8 py-4 bg-orange-600 hover:bg-orange-700 text-white font-semibold rounded-2xl transition-colors duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                Xaridni Boshlash
              </button>
              <button className="px-8 py-4 bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white font-semibold rounded-2xl transition-colors duration-200 border border-white/20">
                Aksiyalarni Ko'rish
              </button>
            </div>
          </div>
        </div>
        
        {/* Decorative Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-yellow-400 rounded-full opacity-20 animate-bounce"></div>
        <div className="absolute bottom-20 right-10 w-16 h-16 bg-orange-400 rounded-full opacity-20 animate-pulse"></div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-white dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Kategoriyalar
            </h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Barcha ehtiyojlaringiz uchun keng tanlangan mahsulotlar katalogi
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {categories.map((category) => (
              <div
                key={category.id}
                onClick={() => onPageChange('products')}
                className="group cursor-pointer"
              >
                <div className="bg-gray-50 dark:bg-slate-700 rounded-2xl p-6 text-center hover:shadow-lg transition-all duration-300 transform group-hover:-translate-y-2 border border-gray-100 dark:border-slate-600">
                  <div className={`${category.color} rounded-2xl p-4 mx-auto w-16 h-16 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    {getIconComponent(category.icon)}
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                    {category.nameUz}
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {category.productCount} mahsulot
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50 dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                Tavsiya Etilgan Mahsulotlar
              </h2>
              <p className="text-gray-600 dark:text-gray-400">
                Eng mashhur va sifatli mahsulotlarimiz
              </p>
            </div>
            <button
              onClick={() => onPageChange('products')}
              className="flex items-center text-green-700 dark:text-green-400 hover:text-green-800 dark:hover:text-green-300 font-semibold"
            >
              Barchasini Ko'rish <ChevronRight className="ml-1 h-5 w-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onProductClick={onProductClick}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Nega Bizni Tanlaysiz?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Award className="h-8 w-8" />,
                title: "Yuqori Sifat",
                description: "Faqat eng yaxshi brendlardan mahsulotlar"
              },
              {
                icon: <Truck className="h-8 w-8" />,
                title: "Tez Yetkazib Berish",
                description: "24 soat ichida sizning uyingizgacha"
              },
              {
                icon: <Shield className="h-8 w-8" />,
                title: "Kafolat",
                description: "Barcha mahsulotlarga 100% kafolat"
              },
              {
                icon: <HeadphonesIcon className="h-8 w-8" />,
                title: "24/7 Qo'llab-quvvatlash",
                description: "Har doim sizning xizmatingizdamiz"
              }
            ].map((feature, index) => (
              <div key={index} className="text-center group">
                <div className="bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400 rounded-2xl p-4 w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50 dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Mijozlarning Fikrlari
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Quvonchli mijozlarimizning mulohazalari
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div
                key={testimonial.id}
                className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-100 dark:border-slate-700"
              >
                <div className="flex items-center mb-4">
                  <img
                    src={testimonial.avatar}
                    alt={testimonial.nameUz}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">
                      {testimonial.nameUz}
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {testimonial.location}
                    </p>
                  </div>
                </div>

                <div className="flex items-center mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < testimonial.rating
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-300 dark:text-gray-600'
                      }`}
                    />
                  ))}
                </div>

                <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
                  "{testimonial.textUz}"
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Homepage;