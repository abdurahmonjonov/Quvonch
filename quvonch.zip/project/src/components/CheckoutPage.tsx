import React, { useState } from 'react';
import { ArrowLeft, CreditCard, MapPin, User, Phone, Mail, CheckCircle } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

interface CheckoutPageProps {
  onBack: () => void;
  onOrderComplete: () => void;
}

const CheckoutPage: React.FC<CheckoutPageProps> = ({ onBack, onOrderComplete }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    region: '',
    postalCode: '',
    paymentMethod: 'card'
  });

  const { items, totalPrice, clearCart } = useCart();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('uz-UZ').format(price) + ' so\'m';
  };

  const deliveryFee = totalPrice >= 150000 ? 0 : 15000;
  const finalTotal = totalPrice + deliveryFee;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      setStep(2);
    } else if (step === 2) {
      setStep(3);
    } else {
      // Complete order
      clearCart();
      onOrderComplete();
    }
  };

  const isStep1Valid = formData.firstName && formData.lastName && formData.email && formData.phone && formData.address && formData.city;
  const isStep2Valid = formData.paymentMethod;

  if (step === 4) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors duration-300 flex items-center justify-center">
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-8 shadow-lg border border-gray-100 dark:border-slate-700 max-w-md w-full mx-4 text-center">
          <div className="text-green-600 text-6xl mb-6">🎉</div>
          <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Rahmat!
          </h2>
          <h3 className="text-lg font-semibold text-green-700 dark:text-green-400 mb-4">
            Sizning buyurtmangiz qabul qilindi!
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Tez orada siz bilan bog'lanamiz va buyurtmangizni yetkazib beramiz.
          </p>
          <button
            onClick={onBack}
            className="w-full bg-green-700 hover:bg-green-800 text-white font-semibold py-3 rounded-xl transition-colors duration-200"
          >
            Bosh sahifaga qaytish
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors duration-300">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="flex items-center text-green-700 dark:text-green-400 hover:text-green-800 dark:hover:text-green-300 transition-colors duration-200"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Orqaga qaytish
          </button>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            To'lov
          </h1>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-4">
            {[
              { num: 1, title: 'Yetkazib berish' },
              { num: 2, title: 'To\'lov' },
              { num: 3, title: 'Tasdiqlash' }
            ].map((stepItem) => (
              <div key={stepItem.num} className="flex items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                    step >= stepItem.num
                      ? 'bg-green-700 text-white'
                      : 'bg-gray-200 dark:bg-slate-700 text-gray-600 dark:text-gray-400'
                  }`}
                >
                  {stepItem.num}
                </div>
                <span className={`ml-2 text-sm font-medium ${
                  step >= stepItem.num
                    ? 'text-green-700 dark:text-green-400'
                    : 'text-gray-600 dark:text-gray-400'
                }`}>
                  {stepItem.title}
                </span>
                {stepItem.num < 3 && (
                  <div className={`ml-4 w-8 h-0.5 ${
                    step > stepItem.num
                      ? 'bg-green-700'
                      : 'bg-gray-200 dark:bg-slate-700'
                  }`}></div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Step 1: Shipping Information */}
              {step === 1 && (
                <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-md border border-gray-100 dark:border-slate-700">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center">
                    <MapPin className="h-5 w-5 mr-2" />
                    Yetkazib berish ma'lumotlari
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Ism *
                      </label>
                      <input
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Familiya *
                      </label>
                      <input
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Telefon raqam *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                        placeholder="+998 90 123 45 67"
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Email *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none text-gray-900 dark:text-white"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Manzil *
                      </label>
                      <input
                        type="text"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Shahar *
                      </label>
                      <input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Viloyat
                      </label>
                      <select
                        name="region"
                        value={formData.region}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none text-gray-900 dark:text-white"
                      >
                        <option value="">Viloyatni tanlang</option>
                        <option value="tashkent">Toshkent</option>
                        <option value="samarkand">Samarqand</option>
                        <option value="bukhara">Buxoro</option>
                        <option value="fergana">Farg'ona</option>
                        <option value="namangan">Namangan</option>
                        <option value="andijan">Andijon</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Payment Method */}
              {step === 2 && (
                <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-md border border-gray-100 dark:border-slate-700">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center">
                    <CreditCard className="h-5 w-5 mr-2" />
                    To'lov usuli
                  </h2>

                  <div className="space-y-4">
                    <label className="flex items-center p-4 border border-gray-200 dark:border-slate-600 rounded-xl cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors duration-200">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="card"
                        checked={formData.paymentMethod === 'card'}
                        onChange={handleInputChange}
                        className="text-green-600 focus:ring-green-500"
                      />
                      <div className="ml-3">
                        <div className="text-gray-900 dark:text-white font-medium">Plastik karta</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Visa, MasterCard, Humo, UzCard</div>
                      </div>
                    </label>

                    <label className="flex items-center p-4 border border-gray-200 dark:border-slate-600 rounded-xl cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors duration-200">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="cash"
                        checked={formData.paymentMethod === 'cash'}
                        onChange={handleInputChange}
                        className="text-green-600 focus:ring-green-500"
                      />
                      <div className="ml-3">
                        <div className="text-gray-900 dark:text-white font-medium">Naqd pul</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Yetkazib berishda to'lov</div>
                      </div>
                    </label>

                    <label className="flex items-center p-4 border border-gray-200 dark:border-slate-600 rounded-xl cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors duration-200">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="payme"
                        checked={formData.paymentMethod === 'payme'}
                        onChange={handleInputChange}
                        className="text-green-600 focus:ring-green-500"
                      />
                      <div className="ml-3">
                        <div className="text-gray-900 dark:text-white font-medium">Payme</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Onlayn to'lov</div>
                      </div>
                    </label>
                  </div>
                </div>
              )}

              {/* Step 3: Order Confirmation */}
              {step === 3 && (
                <div className="space-y-6">
                  <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-md border border-gray-100 dark:border-slate-700">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                      Buyurtmangizni tasdiqlang
                    </h2>

                    <div className="space-y-4">
                      <div className="border-b border-gray-200 dark:border-slate-700 pb-4">
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Yetkazib berish manzili:</h3>
                        <p className="text-gray-600 dark:text-gray-400">
                          {formData.firstName} {formData.lastName}<br />
                          {formData.address}, {formData.city}<br />
                          Telefon: {formData.phone}<br />
                          Email: {formData.email}
                        </p>
                      </div>

                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-2">To'lov usuli:</h3>
                        <p className="text-gray-600 dark:text-gray-400">
                          {formData.paymentMethod === 'card' && 'Plastik karta'}
                          {formData.paymentMethod === 'cash' && 'Naqd pul (yetkazib berishda)'}
                          {formData.paymentMethod === 'payme' && 'Payme'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-md border border-gray-100 dark:border-slate-700">
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Buyurtma tafsilotlari:</h3>
                    <div className="space-y-3">
                      {items.map((item) => (
                        <div key={item.id} className="flex justify-between items-center">
                          <div>
                            <span className="text-gray-900 dark:text-white">{item.nameUz}</span>
                            <span className="text-gray-600 dark:text-gray-400 ml-2">× {item.quantity}</span>
                          </div>
                          <span className="font-semibold text-gray-900 dark:text-white">
                            {formatPrice(item.price * item.quantity)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={
                  (step === 1 && !isStep1Valid) ||
                  (step === 2 && !isStep2Valid)
                }
                className="w-full bg-orange-600 hover:bg-orange-700 disabled:bg-gray-400 text-white font-semibold py-4 rounded-xl transition-colors duration-200"
              >
                {step === 1 && 'To\'lov usuliga o\'tish'}
                {step === 2 && 'Tasdiqlashga o\'tish'}
                {step === 3 && 'Buyurtmani berish'}
              </button>
            </form>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-md border border-gray-100 dark:border-slate-700 sticky top-8">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                Buyurtma xulasasi
              </h2>

              <div className="space-y-3 mb-6">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center space-x-3">
                    <img
                      src={item.image}
                      alt={item.nameUz}
                      className="w-12 h-12 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">
                        {item.nameUz}
                      </p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">
                        {item.quantity} × {formatPrice(item.price)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-3 border-t border-gray-200 dark:border-slate-700 pt-4">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Mahsulotlar</span>
                  <span className="font-semibold text-gray-900 dark:text-white">
                    {formatPrice(totalPrice)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Yetkazib berish</span>
                  <span className="font-semibold text-gray-900 dark:text-white">
                    {deliveryFee === 0 ? 'Bepul' : formatPrice(deliveryFee)}
                  </span>
                </div>
                <div className="flex justify-between text-lg font-bold">
                  <span className="text-gray-900 dark:text-white">Jami</span>
                  <span className="text-green-700 dark:text-green-400">
                    {formatPrice(finalTotal)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;