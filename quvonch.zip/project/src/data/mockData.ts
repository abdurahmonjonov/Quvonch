import { Product, Category, Testimonial } from '../types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Electronics',
    nameUz: 'Elektronika',
    icon: 'Smartphone',
    color: 'bg-blue-500',
    productCount: 156
  },
  {
    id: '2',
    name: 'Fashion',
    nameUz: 'Moda',
    icon: 'Shirt',
    color: 'bg-pink-500',
    productCount: 243
  },
  {
    id: '3',
    name: 'Home & Garden',
    nameUz: 'Uy va bog\'',
    icon: 'Home',
    color: 'bg-green-500',
    productCount: 89
  },
  {
    id: '4',
    name: 'Sports',
    nameUz: 'Sport',
    icon: 'Dumbbell',
    color: 'bg-orange-500',
    productCount: 67
  },
  {
    id: '5',
    name: 'Books',
    nameUz: 'Kitoblar',
    icon: 'Book',
    color: 'bg-purple-500',
    productCount: 134
  },
  {
    id: '6',
    name: 'Beauty',
    nameUz: 'Go\'zallik',
    icon: 'Sparkles',
    color: 'bg-red-500',
    productCount: 198
  }
];

export const products: Product[] = [
  {
    id: '1',
    name: 'Wireless Headphones',
    nameUz: 'Simsiz quloqchin',
    price: 299000,
    originalPrice: 399000,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg',
    images: [
      'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg',
      'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg'
    ],
    category: '1',
    rating: 4.5,
    reviews: 124,
    description: 'Premium wireless headphones with noise cancellation',
    descriptionUz: 'Shovqinni bekor qiluvchi premium simsiz quloqchin',
    inStock: true,
    featured: true
  },
  {
    id: '2',
    name: 'Cotton T-Shirt',
    nameUz: 'Paxta ko\'ylak',
    price: 45000,
    image: 'https://images.pexels.com/photos/1656684/pexels-photo-1656684.jpeg',
    images: [
      'https://images.pexels.com/photos/1656684/pexels-photo-1656684.jpeg'
    ],
    category: '2',
    rating: 4.2,
    reviews: 87,
    description: 'Comfortable 100% cotton t-shirt',
    descriptionUz: '100% paxta qulay ko\'ylak',
    inStock: true
  },
  {
    id: '3',
    name: 'Smart Watch',
    nameUz: 'Aqlli soat',
    price: 189000,
    originalPrice: 259000,
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg',
    images: [
      'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg'
    ],
    category: '1',
    rating: 4.7,
    reviews: 203,
    description: 'Feature-rich smartwatch with health tracking',
    descriptionUz: 'Salomatlikni kuzatuvchi ko\'p funksiyali aqlli soat',
    inStock: true,
    featured: true
  },
  {
    id: '4',
    name: 'Indoor Plant',
    nameUz: 'Uy o\'simligi',
    price: 25000,
    image: 'https://images.pexels.com/photos/1084199/pexels-photo-1084199.jpeg',
    images: [
      'https://images.pexels.com/photos/1084199/pexels-photo-1084199.jpeg'
    ],
    category: '3',
    rating: 4.3,
    reviews: 56,
    description: 'Beautiful indoor plant for home decoration',
    descriptionUz: 'Uy bezagi uchun chiroyli ichki o\'simlik',
    inStock: true
  },
  {
    id: '5',
    name: 'Yoga Mat',
    nameUz: 'Yoga gilami',
    price: 35000,
    image: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg',
    images: [
      'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg'
    ],
    category: '4',
    rating: 4.4,
    reviews: 92,
    description: 'Non-slip yoga mat for comfortable practice',
    descriptionUz: 'Qulay mashq uchun sirg\'almaydigan yoga gilami',
    inStock: true
  },
  {
    id: '6',
    name: 'Programming Book',
    nameUz: 'Dasturlash kitobi',
    price: 85000,
    image: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg',
    images: [
      'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg'
    ],
    category: '5',
    rating: 4.8,
    reviews: 178,
    description: 'Complete guide to modern programming',
    descriptionUz: 'Zamonaviy dasturlash bo\'yicha to\'liq qo\'llanma',
    inStock: true,
    featured: true
  }
];

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Aziza Karimova',
    nameUz: 'Aziza Karimova',
    text: 'Amazing shopping experience! Fast delivery and great quality products.',
    textUz: 'Ajoyib xarid tajribasi! Tez yetkazib berish va sifatli mahsulotlar.',
    rating: 5,
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
    location: 'Toshkent'
  },
  {
    id: '2',
    name: 'Bobur Abdullayev',
    nameUz: 'Bobur Abdullayev',
    text: 'Excellent customer service and competitive prices. Highly recommended!',
    textUz: 'Ajoyib mijozlar xizmati va raqobatbardosh narxlar. Tavsiya qilaman!',
    rating: 5,
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
    location: 'Samarqand'
  },
  {
    id: '3',
    name: 'Nilufar Tursunova',
    nameUz: 'Nilufar Tursunova',
    text: 'Love the variety of products and the user-friendly website!',
    textUz: 'Mahsulotlar xilma-xilligi va foydalanuvchi uchun qulay veb-sayt!',
    rating: 5,
    avatar: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg',
    location: 'Buxoro'
  }
];