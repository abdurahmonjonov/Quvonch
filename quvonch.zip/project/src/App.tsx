import React, { useState } from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { CartProvider } from './contexts/CartContext';
import Header from './components/Header';
import Homepage from './components/Homepage';
import ProductListPage from './components/ProductListPage';
import ProductDetailPage from './components/ProductDetailPage';
import CartPage from './components/CartPage';
import CheckoutPage from './components/CheckoutPage';
import { Product } from './types';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const handlePageChange = (page: string) => {
    setCurrentPage(page);
    setSelectedProduct(null);
  };

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setCurrentPage('product-detail');
  };

  const handleBackFromProduct = () => {
    setCurrentPage('products');
    setSelectedProduct(null);
  };

  const handleBackFromCart = () => {
    setCurrentPage('home');
  };

  const handleCheckout = () => {
    setCurrentPage('checkout');
  };

  const handleOrderComplete = () => {
    setCurrentPage('home');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <Homepage
            onPageChange={handlePageChange}
            onProductClick={handleProductClick}
          />
        );
      case 'products':
        return (
          <ProductListPage onProductClick={handleProductClick} />
        );
      case 'product-detail':
        return selectedProduct ? (
          <ProductDetailPage
            product={selectedProduct}
            onBack={handleBackFromProduct}
            onProductClick={handleProductClick}
          />
        ) : null;
      case 'cart':
        return (
          <CartPage
            onBack={handleBackFromCart}
            onCheckout={handleCheckout}
          />
        );
      case 'checkout':
        return (
          <CheckoutPage
            onBack={() => setCurrentPage('cart')}
            onOrderComplete={handleOrderComplete}
          />
        );
      case 'about':
        return (
          <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors duration-300 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                Biz Haqimizda
              </h1>
              <p className="text-gray-600 dark:text-gray-400 max-w-2xl">
                Quvonch Savdo Markazi - O'zbekistonda eng yaxshi mahsulotlarni taqdim etuvchi onlayn do'kon. 
                Bizning maqsadimiz - har bir mijozimizga quvonch va mamnunlik keltirish.
              </p>
            </div>
          </div>
        );
      case 'blog':
        return (
          <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors duration-300 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                Quvonch Blog
              </h1>
              <p className="text-gray-600 dark:text-gray-400 max-w-2xl">
                Eng so'nggi yangiliklar, maslahatlar va mahsulot sharhlari. Tez orada!
              </p>
            </div>
          </div>
        );
      default:
        return (
          <Homepage
            onPageChange={handlePageChange}
            onProductClick={handleProductClick}
          />
        );
    }
  };

  return (
    <ThemeProvider>
      <CartProvider>
        <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors duration-300">
          <Header currentPage={currentPage} onPageChange={handlePageChange} />
          {renderPage()}
        </div>
      </CartProvider>
    </ThemeProvider>
  );
}

export default App;